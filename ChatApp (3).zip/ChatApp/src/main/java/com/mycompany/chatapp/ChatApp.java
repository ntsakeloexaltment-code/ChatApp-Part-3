/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.chatapp;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class ChatApp {
// Part 3 — all message arrays live in MessageStorage
private static MessageStorage storage = new MessageStorage();
private static int messageCounter = 0;
private static boolean isLoggedIn = false; // MUST be false at start

public static void main(String[] args) {
Scanner scanner = new Scanner(System.in);

System.out.println("================================");
System.out.println(" CHAT APP");
System.out.println("================================");

// --- Registration ---
System.out.print("Enter your first name: ");
String firstName = scanner.nextLine().trim();
System.out.print("Enter your last name: ");
String lastName = scanner.nextLine().trim();

System.out.println("\n--- REGISTRATION ---");
String username = getValidUsername(scanner);
String password = getValidPassword(scanner);
String phoneNumber = getValidCell(scanner);

String regResult = RegistrationApp.registerUser(username, password, phoneNumber, firstName, lastName);
System.out.println("\n" + regResult);

// --- LOGIN ---
System.out.println("\n--- LOGIN ---");

// Loop ONLY while NOT logged in
while (!isLoggedIn) {
System.out.print("Enter username: ");
String loginUser = scanner.nextLine().trim();
System.out.print("Enter password: ");
String loginPass = scanner.nextLine().trim();

String status = RegistrationApp.returnLoginStatus(loginUser, loginPass);
System.out.println("\n" + status);

if (RegistrationApp.loginUser(loginUser, loginPass)) {
isLoggedIn = true;
System.out.println("Opening chat menu...\n");
} else {
System.out.println("Please try again.\n");
}
}

// --- Part 3: read previously stored messages from the JSON file ---
int loaded = storage.loadStoredMessagesFromJson();
if (loaded > 0) {
System.out.println(loaded + " stored message(s) loaded from " + MessageStorage.DEFAULT_JSON_FILE + ".");
}
messageCounter = storage.getHighestMessageNumber();

// --- MENU STARTS AFTER LOGIN ---
System.out.println("Welcome to QuickChat.");
System.out.print("How many messages do you wish to enter? ");
int numToSend = getPositiveIntInput(scanner);

boolean running = true;
while (running) {
System.out.println("\n=== MENU ===");
System.out.println("Option 1) Send Messages");
System.out.println("Option 2) Show recently sent messages");
System.out.println("Option 3) Quit");
System.out.println("Option 4) Stored Messages");
System.out.print("Enter your choice: ");

String choice = scanner.nextLine().trim();
switch (choice) {
case "1":
sendMessagesMenu(scanner, numToSend);
break;
case "2":
System.out.println("\n--- Recently Sent Messages ---");
System.out.println(storage.displaySentMessages());
break;
case "3":
System.out.println("\nTotal messages sent: " + storage.getTotalSentMessages());
System.out.println("Exiting application. Goodbye!");
running = false;
break;
case "4":
storedMessagesMenu(scanner);
break;
default:
System.out.println("Invalid option. Please try again.");
}
}
scanner.close();
}

// === Helper Methods ===
private static String getValidUsername(Scanner sc) {
while (true) {
System.out.print("Enter username: ");
String u = sc.nextLine().trim();
if (RegistrationApp.checkUserName(u)) {
System.out.println("Username successfully captured.");
return u;
}
System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
}
}

private static String getValidPassword(Scanner sc) {
while (true) {
System.out.print("Enter password: ");
String p = sc.nextLine().trim();
if (RegistrationApp.checkPasswordComplexity(p)) {
System.out.println("Password successfully captured.");
return p;
}
System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
}
}

private static String getValidCell(Scanner sc) {
while (true) {
System.out.print("Enter cell phone number with international code (e.g. +27838968976): ");
String c = sc.nextLine().trim();
if (RegistrationApp.checkCellPhoneNumber(c)) {
System.out.println("Cell phone number successfully added.");
return c;
}
System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
}
}

private static int getPositiveIntInput(Scanner sc) {
while (true) {
try {
int n = Integer.parseInt(sc.nextLine().trim());
if (n > 0) return n;
System.out.print("Please enter a positive number: ");
} catch (NumberFormatException e) {
System.out.print("Invalid number. Try again: ");
}
}
}

private static void sendMessagesMenu(Scanner sc, int howMany) {
if (!isLoggedIn) {
System.out.println("You must be logged in to send messages.");
return;
}

for (int i = 0; i < howMany; i++) {
messageCounter++;
Message msg = new Message();
msg.setMessageNumber(messageCounter);
msg.setSender(RegistrationApp.getRegisteredCellPhoneNumber());

while (true) {
System.out.print("\nMessage " + (i+1) + " - Enter recipient cell (with +code): ");
String cell = sc.nextLine().trim();
String check = msg.checkRecipientCell(cell);
System.out.println(check);
if (check.contains("successfully")) {
msg.setRecipientCell(cell);
break;
}
}

while (true) {
System.out.print("Enter message (max 250 chars): ");
String text = sc.nextLine().trim();
if (text.isEmpty()) {
System.out.println("Message cannot be empty.");
continue;
}
String check = msg.checkMessageLength(text);
System.out.println(check);
if (check.equals("Message ready to send.")) {
msg.setMessageText(text);
break;
}
}

msg.generateMessageID();
String hash = msg.createMessageHash();

System.out.println("\n--- Message Details ---");
System.out.println("Message ID: " + msg.getMessageID());
System.out.println("Message Hash: " + hash);
System.out.println("Recipient: " + msg.getRecipientCell());
System.out.println("Message: " + msg.getMessageText());

System.out.println("\nChoose an option:");
System.out.println("1) Send Message");
System.out.println("2) Disregard Message");
System.out.println("3) Store Message to send later");
System.out.print("Enter choice: ");
int action = getPositiveIntInput(sc);
while (action < 1 || action > 3) {
System.out.print("Invalid choice. Enter 1, 2 or 3: ");
action = getPositiveIntInput(sc);
}

// Part 3 — puts the message into the Sent / Disregarded / Stored array
String result = storage.addMessage(msg, action);
System.out.println(result);
}

System.out.println("\n--- All Sent Messages ---");
System.out.println(storage.displaySentMessages());
System.out.println("Total messages sent: " + storage.getTotalSentMessages());
}

// ==========================================
// Part 3 — Option 4: Stored Messages menu
// ==========================================
private static void storedMessagesMenu(Scanner sc) {
boolean inMenu = true;
while (inMenu) {
System.out.println("\n=== STORED MESSAGES ===");
System.out.println("a) Display sender and recipient of all stored messages");
System.out.println("b) Display the longest stored message");
System.out.println("c) Search for a message ID");
System.out.println("d) Search for all messages stored for a recipient");
System.out.println("e) Delete a message using the message hash");
System.out.println("f) Display report of all stored messages");
System.out.println("x) Back to main menu");
System.out.print("Enter your choice: ");

String choice = sc.nextLine().trim().toLowerCase();
switch (choice) {
case "a":
System.out.println(storage.displaySendersAndRecipients());
break;
case "b":
System.out.println("Longest stored message: " + storage.getLongestStoredMessage());
break;
case "c":
System.out.print("Enter message ID: ");
System.out.println(storage.searchByMessageID(sc.nextLine().trim()));
break;
case "d":
System.out.print("Enter recipient cell (with +code): ");
System.out.println(storage.displayMessagesForRecipient(sc.nextLine().trim()));
break;
case "e":
System.out.print("Enter message hash: ");
System.out.println(storage.deleteByHash(sc.nextLine().trim()));
break;
case "f":
System.out.println(storage.displayStoredMessagesReport());
break;
case "x":
inMenu = false;
break;
default:
System.out.println("Invalid option. Please try again.");
}
}
}
}