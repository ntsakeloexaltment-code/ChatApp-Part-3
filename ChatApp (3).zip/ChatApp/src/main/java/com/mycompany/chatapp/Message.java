/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Student
 */

  import java.util.Random;

public class Message {
    private String messageID;
    private int messageNumber;
    private String sender;
    private String recipientCell;
    private String messageText;
    private String messageHash;
    private boolean isSent;
    private boolean isStored;

    // === GETTERS ===
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getSender() { return sender; }
    public String getRecipientCell() { return recipientCell; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }

    // === SETTERS ===
    public void setMessageNumber(int num) { this.messageNumber = num; }
    public void setSender(String sender) { this.sender = sender; }
    public void setRecipientCell(String cell) { this.recipientCell = cell; }
    public void setMessageText(String text) { this.messageText = text; }

    // === Generate Message ID ===
    public String generateMessageID() {
        Random rand = new Random();
        long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
        this.messageID = String.valueOf(id);
        return this.messageID;
    }

    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }

    // === Validate Recipient Cell ===
    public String checkRecipientCell(String cell) {
        if (cell != null && cell.matches("^\\+\\d{10,}$")) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    // === Validate Message Length ===
    public String checkMessageLength(String text) {
        if (text == null) {
            return "Message exceeds 250 characters by 250; please reduce the size.";
        }
        if (text.length() > 250) {
            int over = text.length() - 250;
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
        return "Message ready to send.";
    }

    // === Create Message Hash — LINE 83 FIXED ===
    public String createMessageHash() {
        if (messageID == null || messageID.length() < 2) {
            return "";
        }
        if (messageText == null || messageText.trim().isEmpty()) {
            return "";
        }
        
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.trim().split("\\s+");
        
        String firstWord = words[0].replaceAll("[^a-zA-Z0-9]", "");
        String lastWord = words[words.length - 1].replaceAll("[^a-zA-Z0-9]", "");
        
        messageHash = (firstTwo + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
        return messageHash;
    }

    public String sentMessage(int choice) {
        switch (choice) {
            case 1:
                isSent = true;
                isStored = false;
                return "Message successfully sent.";
            case 2:
                isSent = false;
                return "Press 0 to delete the message.";
            case 3:
                isSent = false;
                isStored = true;
                return "Message successfully stored.";
            default:
                return "Invalid choice.";
        }
    }

    public String printMessages() {
        return messageID + " | " + messageHash + " | " + recipientCell + " | " + messageText;
    }

    public int returnTotalMessages() {
        return isSent ? 1 : 0;
    }
}
