/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapp;

/**
 *
 * @author Student
 */
import java.io.*;
import java.nio.file.*;
import java.util.*;

public class MessageStorage {
    public static final String DEFAULT_JSON_FILE = "stored_messages.json";

    // ==============================================
    // PART 3 — REQUIRED PARALLEL ARRAYS
    // ==============================================
    private ArrayList<String> sentMessages = new ArrayList<>();
    private ArrayList<String> disregardedMessages = new ArrayList<>();
    
    // Stored Messages — Parallel Arrays
    private ArrayList<String> storedMessageIDs = new ArrayList<>();
    private ArrayList<String> storedMessageHashes = new ArrayList<>();
    private ArrayList<String> storedSenders = new ArrayList<>();
    private ArrayList<String> storedRecipients = new ArrayList<>();
    private ArrayList<String> storedMessageTexts = new ArrayList<>();

    // === Getters for Unit Tests ===
    public ArrayList<String> getSentMessages() { return sentMessages; }
    public ArrayList<String> getDisregardedMessages() { return disregardedMessages; }
    public ArrayList<String> getStoredMessageIDs() { return storedMessageIDs; }
    public ArrayList<String> getStoredMessageHashes() { return storedMessageHashes; }
    public ArrayList<String> getStoredSenders() { return storedSenders; }
    public ArrayList<String> getStoredRecipients() { return storedRecipients; }
    public ArrayList<String> getStoredMessageTexts() { return storedMessageTexts; }

    // ==============================================
    // ADD MESSAGE — Populate Arrays
    // ==============================================
    public String addMessage(Message msg, int action) {
        String result = msg.sentMessage(action);
        
        switch (action) {
            case 1: // Send
                sentMessages.add(msg.getMessageText());
                return "✅ " + result + " Added to Sent Messages.";
            case 2: // Disregard
                disregardedMessages.add(msg.getMessageText());
                return "⚠️ Message disregarded and saved.";
            case 3: // Store
                storedMessageIDs.add(msg.getMessageID());
                storedMessageHashes.add(msg.getMessageHash());
                storedSenders.add(msg.getSender());
                storedRecipients.add(msg.getRecipientCell());
                storedMessageTexts.add(msg.getMessageText());
                saveStoredMessagesToJson();
                return "📦 " + result + "\n   ID: " + msg.getMessageID() + "\n   Hash: " + msg.getMessageHash();
            default:
                return "Invalid action.";
        }
    }

    // ==============================================
    // SAVE JSON — Rubric Requirement
    // ==============================================
    public void saveStoredMessagesToJson() {
        try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(DEFAULT_JSON_FILE))) {
            writer.write("[\n");
            for (int i = 0; i < storedMessageTexts.size(); i++) {
                writer.write("  {\n");
                writer.write("    \"messageID\": \"" + escapeJson(storedMessageIDs.get(i)) + "\",\n");
                writer.write("    \"messageHash\": \"" + escapeJson(storedMessageHashes.get(i)) + "\",\n");
                writer.write("    \"sender\": \"" + escapeJson(storedSenders.get(i)) + "\",\n");
                writer.write("    \"recipient\": \"" + escapeJson(storedRecipients.get(i)) + "\",\n");
                writer.write("    \"messageText\": \"" + escapeJson(storedMessageTexts.get(i)) + "\"\n");
                writer.write("  }" + (i < storedMessageTexts.size() - 1 ? "," : "") + "\n");
            }
            writer.write("]\n");
        } catch (IOException e) {
            System.err.println("⚠️ Error saving JSON file: " + e.getMessage());
        }
    }

    // ==============================================
    // READ JSON — Rubric Requirement
    // ==============================================
    public int loadStoredMessagesFromJson() {
        storedMessageIDs.clear();
        storedMessageHashes.clear();
        storedSenders.clear();
        storedRecipients.clear();
        storedMessageTexts.clear();

        try {
            String content = Files.readString(Paths.get(DEFAULT_JSON_FILE)).trim();
            if (content.equals("[]") || content.isEmpty()) return 0;

            content = content.substring(1, content.length() - 1).trim();
            if (content.isEmpty()) return 0;

            String[] blocks = content.split("\\},\\s*\\{");

            for (String block : blocks) {
                block = block.replace("{", "").replace("}", "").trim();

                String id = extractJsonValue(block, "messageID");
                String hash = extractJsonValue(block, "messageHash");
                String sender = extractJsonValue(block, "sender");
                String recipient = extractJsonValue(block, "recipient");
                String text = extractJsonValue(block, "messageText");

                if (!id.isEmpty() && !text.isEmpty()) {
                    storedMessageIDs.add(id);
                    storedMessageHashes.add(hash);
                    storedSenders.add(sender);
                    storedRecipients.add(recipient);
                    storedMessageTexts.add(text);
                }
            }
            return storedMessageTexts.size();
        } catch (IOException e) {
            return 0;
        }
    }

    private String extractJsonValue(String block, String key) {
        String search = "\"" + key + "\":\"";
        int start = block.indexOf(search);
        if (start == -1) return "";
        start += search.length();
        int end = block.indexOf("\"", start);
        if (end == -1) return "";
        return block.substring(start, end).replace("\\\"", "\"");
    }

    private String escapeJson(String text) {
        return text.replace("\"", "\\\"");
    }

    // ==============================================
    // FEATURE a) Display Sender & Recipient
    // ==============================================
    public String displaySendersAndRecipients() {
        StringBuilder sb = new StringBuilder();
        sb.append("--- Sender & Recipient List ---\n");
        if (storedMessageTexts.isEmpty()) {
            sb.append("No stored messages.\n");
            return sb.toString();
        }
        for (int i = 0; i < storedMessageTexts.size(); i++) {
            sb.append("From: ").append(storedSenders.get(i))
              .append("  →  To: ").append(storedRecipients.get(i)).append("\n");
        }
        return sb.toString();
    }

    // ==============================================
    // FEATURE b) Get Longest Stored Message
    // ==============================================
    public String getLongestStoredMessage() {
        if (storedMessageTexts.isEmpty()) return "";
        int longestIndex = 0;
        for (int i = 1; i < storedMessageTexts.size(); i++) {
            if (storedMessageTexts.get(i).length() > storedMessageTexts.get(longestIndex).length()) {
                longestIndex = i;
            }
        }
        return storedMessageTexts.get(longestIndex);
    }

    // ==============================================
    // FEATURE c) Search by Message ID
    // ==============================================
    public String searchByMessageID(String searchID) {
        for (int i = 0; i < storedMessageIDs.size(); i++) {
            if (storedMessageIDs.get(i).equals(searchID)) {
                return "Recipient: " + storedRecipients.get(i) + " | Message: \"" + storedMessageTexts.get(i) + "\"";
            }
        }
        return "Message ID not found.";
    }

    // ==============================================
    // FEATURE d) Search Messages by Recipient
    // ==============================================
    public String displayMessagesForRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        boolean found = false;
        for (int i = 0; i < storedRecipients.size(); i++) {
            if (storedRecipients.get(i).equals(recipient)) {
                sb.append("\"").append(storedMessageTexts.get(i)).append("\"\n");
                found = true;
            }
        }
        if (!found) {
            return "No messages found for recipient: " + recipient;
        }
        return sb.toString().trim();
    }

    // ==============================================
    // FEATURE e) Delete Message by Hash
    // ==============================================
    public String deleteByHash(String hash) {
        for (int i = 0; i < storedMessageHashes.size(); i++) {
            if (storedMessageHashes.get(i).equals(hash)) {
                String deletedMsg = storedMessageTexts.get(i);
                storedMessageIDs.remove(i);
                storedMessageHashes.remove(i);
                storedSenders.remove(i);
                storedRecipients.remove(i);
                storedMessageTexts.remove(i);
                saveStoredMessagesToJson();
                return "Message: \"" + deletedMsg + "\" successfully deleted.";
            }
        }
        return "Message hash not found.";
    }

    // ==============================================
    // FEATURE f) Display Full Report
    // ==============================================
    public String displayStoredMessagesReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n========== STORED MESSAGES REPORT ==========\n");
        sb.append(String.format("%-14s %-12s %-15s %-15s %s\n", 
            "MessageID", "Hash", "Sender", "Recipient", "Message"));
        sb.append("-----------------------------------------------------------------------\n");
        if (storedMessageTexts.isEmpty()) {
            sb.append("No stored messages to display.\n");
        } else {
            for (int i = 0; i < storedMessageTexts.size(); i++) {
                sb.append(String.format("%-14s %-12s %-15s %-15s \"%s\"\n",
                    storedMessageIDs.get(i),
                    storedMessageHashes.get(i),
                    storedSenders.get(i),
                    storedRecipients.get(i),
                    storedMessageTexts.get(i)));
            }
        }
        sb.append("============================================\n");
        return sb.toString();
    }

    // === Helper Methods ===
    public String displaySentMessages() {
        StringBuilder sb = new StringBuilder();
        if (sentMessages.isEmpty()) {
            sb.append("No sent messages.");
        } else {
            for (int i = 0; i < sentMessages.size(); i++) {
                sb.append((i + 1) + ". ").append(sentMessages.get(i)).append("\n");
            }
        }
        return sb.toString().trim();
    }

    public int getTotalSentMessages() {
        return sentMessages.size();
    }

    public int getHighestMessageNumber() {
        return storedMessageIDs.size();
    }

    public void clearAllData() {
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessageIDs.clear();
        storedMessageHashes.clear();
        storedSenders.clear();
        storedRecipients.clear();
        storedMessageTexts.clear();
    }

}
