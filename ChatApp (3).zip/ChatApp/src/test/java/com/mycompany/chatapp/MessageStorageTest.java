/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.chatapp;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class MessageStorageTest {
    private MessageStorage storage;
    private String msg2Hash;
    private String msg2ID;
    private String msg5Hash;
    private String msg5ID;

    @BeforeEach
    void setUp() {
        storage = new MessageStorage();
        storage.clearAllData();
        
        // Message 1 — Sent
        Message m1 = new Message();
        m1.setSender("0838884567");
        m1.setRecipientCell("+27834557896");
        m1.setMessageText("Did you get the cake?");
        m1.setMessageNumber(1);
        m1.generateMessageID();
        m1.createMessageHash();
        storage.addMessage(m1, 1);

        // Message 2 — Stored
        Message m2 = new Message();
        m2.setSender("0838884567");
        m2.setRecipientCell("+27838884567");
        m2.setMessageText("Where are you? You are late! I have asked you to be on time.");
        m2.setMessageNumber(2);
        msg2ID = m2.generateMessageID();
        msg2Hash = m2.createMessageHash();
        storage.addMessage(m2, 3);

        // Message 3 — Disregarded
        Message m3 = new Message();
        m3.setSender("0838884567");
        m3.setRecipientCell("+27834484567");
        m3.setMessageText("Yohoooo, I am at your gate.");
        m3.setMessageNumber(3);
        m3.generateMessageID();
        m3.createMessageHash();
        storage.addMessage(m3, 2);

        // Message 4 — Sent
        Message m4 = new Message();
        m4.setSender("0838884567");
        m4.setRecipientCell("+27838884567");
        m4.setMessageText("It is dinner time!");
        m4.setMessageNumber(4);
        m4.generateMessageID();
        m4.createMessageHash();
        storage.addMessage(m4, 1);

        // Message 5 — Stored
        Message m5 = new Message();
        m5.setSender("0838884567");
        m5.setRecipientCell("+27838884567");
        m5.setMessageText("Ok, I am leaving without you.");
        m5.setMessageNumber(5);
        msg5ID = m5.generateMessageID();
        msg5Hash = m5.createMessageHash();
        storage.addMessage(m5, 3);
    }

    // ==================================================
    // TEST 1: Sent Messages Array Correctly Populated
    // ==================================================
    @Test
    void test01_SentMessagesPopulatedCorrectly() {
        assertEquals(2, storage.getSentMessages().size(),
                "Should have exactly 2 sent messages");
        assertTrue(storage.getSentMessages().contains("Did you get the cake?"),
                "Should contain Message 1");
        assertTrue(storage.getSentMessages().contains("It is dinner time!"),
                "Should contain Message 4");
    }

    // ==================================================
    // TEST 2: Disregarded Messages Array Correctly Populated
    // ==================================================
    @Test
    void test02_DisregardedMessagesPopulatedCorrectly() {
        assertEquals(1, storage.getDisregardedMessages().size(),
                "Should have exactly 1 disregarded message");
        assertTrue(storage.getDisregardedMessages().contains("Yohoooo, I am at your gate."),
                "Should contain Message 3");
    }

    // ==================================================
    // TEST 3: Stored Messages Arrays Correctly Populated
    // ==================================================
    @Test
    void test03_StoredMessagesArraysPopulatedCorrectly() {
        assertEquals(2, storage.getStoredMessageIDs().size(),
                "Should have 2 stored message IDs");
        assertEquals(2, storage.getStoredMessageHashes().size(),
                "Should have 2 stored message hashes");
        assertEquals(2, storage.getStoredSenders().size(),
                "Should have 2 stored senders");
        assertEquals(2, storage.getStoredRecipients().size(),
                "Should have 2 stored recipients");
        assertEquals(2, storage.getStoredMessageTexts().size(),
                "Should have 2 stored messages");
    }

    // ==================================================
    // TEST 4: Longest Message Correctly Identified
    // ==================================================
    @Test
    void test04_DisplayLongestMessage() {
        String expected = "Where are you? You are late! I have asked you to be on time.";
        assertEquals(expected, storage.getLongestStoredMessage(),
                "Longest stored message should match Message 2");
    }

    // ==================================================
    // TEST 5: Search — Message ID Found
    // ==================================================
    @Test
    void test05_SearchByMessageID_Found() {
        String result = storage.searchByMessageID(msg2ID);
        assertNotEquals("Message ID not found.", result,
                "Stored message ID should be found");
        assertTrue(result.contains("Where are you?"),
                "Result should contain message text");
        assertTrue(result.contains("+27838884567"),
                "Result should contain recipient number");
    }

    // ==================================================
    // TEST 6: Search — Message ID Not Found
    // ==================================================
    @Test
    void test06_SearchByMessageID_NotFound() {
        String result = storage.searchByMessageID("0000000000");
        assertEquals("Message ID not found.", result,
                "Invalid ID should return not found message");
    }

    // ==================================================
    // TEST 7: Search Messages by Recipient — Multiple Results
    // ==================================================
    @Test
    void test07_DisplayMessagesForRecipient_MultipleFound() {
        String recipient = "+27838884567";
        String result = storage.displayMessagesForRecipient(recipient);
        
        assertTrue(result.contains("Where are you?"),
                "Should include Message 2");
        assertTrue(result.contains("Ok, I am leaving without you."),
                "Should include Message 5");
    }

    // ==================================================
    // TEST 8: Search Messages by Recipient — No Results
    // ==================================================
    @Test
    void test08_DisplayMessagesForRecipient_NotFound() {
        String result = storage.displayMessagesForRecipient("+27999999999");
        assertTrue(result.contains("No messages found for recipient"),
                "Unknown recipient should return not found message");
    }

    // ==================================================
    // TEST 9: Delete Message by Hash — Successfully Deleted
    // ==================================================
    @Test
    void test09_DeleteMessageByHash_Success() {
        int before = storage.getStoredMessageTexts().size();
        String result = storage.deleteByHash(msg2Hash);
        int after = storage.getStoredMessageTexts().size();
        
        assertTrue(result.contains("successfully deleted"),
                "Should confirm successful deletion");
        assertEquals(before - 1, after,
                "Stored messages count should decrease by 1");
        assertFalse(storage.getStoredMessageHashes().contains(msg2Hash),
                "Deleted hash should no longer be in array");
    }

    // ==================================================
    // TEST 10: Display Stored Messages Report — Contains All Data
    // ==================================================
    @Test
    void test10_DisplayStoredMessagesReport_Complete() {
        String report = storage.displayStoredMessagesReport();
        
        assertAll(
            () -> assertTrue(report.contains("MessageID"), "Report needs MessageID column"),
            () -> assertTrue(report.contains("Hash"), "Report needs Hash column"),
            () -> assertTrue(report.contains("Sender"), "Report needs Sender column"),
            () -> assertTrue(report.contains("Recipient"), "Report needs Recipient column"),
            () -> assertTrue(report.contains("Where are you?"), "Report should list Message 2"),
            () -> assertTrue(report.contains("Ok, I am leaving without you."), "Report should list Message 5")
        );
    }
}
